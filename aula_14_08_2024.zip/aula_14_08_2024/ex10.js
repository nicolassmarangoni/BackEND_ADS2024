let idademinima = 18 
let idadeusuario = 13

if(idade >= idademinima ){
    console.log('idade suficente para entrar no show')
}else {
    console.log('não tem idade suficiente')
}