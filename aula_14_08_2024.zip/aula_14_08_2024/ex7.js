let numero = 3
if (numero % 2 == 0) {
    console.log('Número Par');
} else { 
    console.log('numero impar');
    }

 