let minhaString = 'Teste'
let comprimento = minhaString.length;
let maiscula = minhaString.toUpperCase()
    console.log(comprimento)
    console.log(maiscula)