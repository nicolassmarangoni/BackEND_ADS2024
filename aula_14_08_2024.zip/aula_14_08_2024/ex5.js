
let nomeOriginal = "Nicolas";

let uppernomeoriginal = nomeOriginal.toUpperCase();

let lowernomeoriginal = nomeOriginal.toLowerCase();

let slicedNomeOriginal = nomeOriginal.slice(2, 5); 

let concatenatedNomeOriginal = nomeOriginal.concat(" Marangoni");


console.log("Original:", nomeOriginal);
console.log("Maiúsculas:", uppernomeoriginal);
console.log("Minúsculas:", lowernomeoriginal);
console.log("Pedaço da string:", slicedNomeOriginal);
console.log("String concatenada:", concatenatedNomeOriginal);
