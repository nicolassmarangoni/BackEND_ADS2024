let admin = true
let statuss = true
if ( admin  && statuss){
    console.log('Acesso concedido. O usuário está logado e é adm')
} else {
    console.log('acesso negado')
}
