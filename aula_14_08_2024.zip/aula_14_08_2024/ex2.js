let nomeString= (undefined)
let nomString = (null)

console.log(nomString)
console.log(nomeString)