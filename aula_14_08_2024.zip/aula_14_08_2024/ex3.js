let idade = 21;                 
let nome = 'Nicolas';        
let palavra = true;            

let resultado = `Meu nome é ${nome}, tenho ${idade} anos e o status da mensagem é ${palavra}.`;


console.log(resultado);