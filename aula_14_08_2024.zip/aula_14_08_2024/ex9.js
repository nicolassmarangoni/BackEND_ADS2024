let variavel1 = true
let variavel2 = false

if ( variavel1 || variavel2){
    console.log ('uma das variaveis é verdadeira')
}